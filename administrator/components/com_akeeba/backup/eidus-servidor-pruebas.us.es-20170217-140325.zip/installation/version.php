<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('AKEEBA_PRO', '0');
define('AKEEBA_VERSION', '4.7.4');
define('AKEEBA_DATE', '2016-07-31');